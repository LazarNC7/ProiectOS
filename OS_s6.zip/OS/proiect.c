#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

#pragma pack(push, 1)
typedef struct {
char signature[2];
int size;
int reserved;
int data_offset;
int header_size;
int width;
int height;
short planes;
short bpp;
int compression;
int image_size;
int x_resolution;
int y_resolution;
int num_colors;
int important_colors;
} BMPHeader;
#pragma pack(pop)



void statistics(char *file){
  int inp, out;
  struct stat info;
  char statistics[500];
  if((inp=open(file, O_RDONLY)) == -1){
    printf("S-a intampinat o eroare la deschiderea fisierului\n");
    exit(2);
  }
  if(fstat(inp, &info)==-1){
    printf("Eroare");
    close(inp);
    exit(2);
  }

  BMPHeader header;
  if(read(inp, &header, sizeof(BMPHeader))!=sizeof(BMPHeader)){
    exit(5);
  }

  //int width=*(int*)((char*)&header+18);
  //int height=*(int*)((char*)&header+22);
  int height=header.height;
  int width=header.width;
  snprintf(statistics, sizeof(statistics),
"nume fisier: %s\ninaltime: %d\nlungime: %d\ndimensiune: %d\nidentificatorul utilizatorului: %d\ntimpul ultimei modificari: %scontorul de legaturi: %ld\ndrepturi de acces user: RWX\ndrepturi de acces grup: R--\ndrepturi de acces altii: ---\n",
	   file,height, width, (int)info.st_size, info.st_uid, ctime(&info.st_mtime), info.st_nlink);

  out = open("statistica.txt", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (out == -1) {
    perror("Eroare la deschiderea fișierului de ieșire");
    close(inp);
    exit(3);
  }

  if (write(out, statistics, strlen(statistics)) == -1) {
    perror("Eroare la scrierea în fișierul de ieșire");
  }
  
  close(inp);
  close(out);
}

int main(int argc, char* args[]){
  if(argc!=2){
    printf("Usage ./program <fisier_intrare>\n");
    exit(1);
  }

  statistics(args[1]);

}
